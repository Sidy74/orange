package com.orange.test.controller

import com.orange.test.dto.PharmacieDto
import com.orange.test.dto.mapper.PharmacieMapping.toDto
import com.orange.test.dto.mapper.PharmacieMapping.toEntity
import com.orange.test.model.Pharmacie
import com.orange.test.service.PharmacieService
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.Mapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController



@RestController
@RequestMapping("/pharmacies")
class PharmacieController(
   private val  pharmacieService:PharmacieService){

    @GetMapping
    fun getPharmacies(): MutableList<Pharmacie> {
        return pharmacieService.readAll();
    }
    @PostMapping
    fun addPharmacie(pharmacieDto: PharmacieDto):PharmacieDto {
        return pharmacieService.create(pharmacieDto)
    }
    @DeleteMapping("/{name}")
    fun deletePharmacieByName(name:String):Boolean{
        return pharmacieService.deleteByName(name)
    }
    @PutMapping("/{id}")
    fun updatePharmacie(
        @PathVariable id: Long,
        @RequestBody updatedPharmacieDto: PharmacieDto
    ): PharmacieDto? {
        // Conversion du DTO en entité
        val updatedPharmacie = updatedPharmacieDto.toEntity()

        // Appel du service pour mettre à jour la pharmacie
        val result = pharmacieService.update(id, updatedPharmacie)

        // Vérification si la mise à jour a réussi
        return result?.toDto() // Retourne le DTO de la pharmacie mise à jour
    }

//    @GetMapping("/with-garde-today")
//    fun getPharmaciesWithGardeToday(): List<PharmacieDto> {
//        return pharmacieService.getPharmaciesWithGardeToday()
//    }
}

