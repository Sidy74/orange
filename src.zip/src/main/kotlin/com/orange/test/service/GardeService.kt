package com.orange.test.service

import com.orange.test.dto.CreateGardeRequestDto
import com.orange.test.dto.GardeDto

interface GardeService {
 fun creerGarde(request: CreateGardeRequestDto): GardeDto;
}