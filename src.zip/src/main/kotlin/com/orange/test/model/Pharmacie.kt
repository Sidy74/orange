package com.orange.test.model

import com.fasterxml.jackson.annotation.JsonIgnore
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.OneToMany
import jakarta.persistence.Table
import lombok.Data

@Entity
@Table
data class Pharmacie (@Id
                 @GeneratedValue(strategy = GenerationType.IDENTITY)
                 var id: Long= 0,
                var nom: String = "",
                var adresse: String = "",
    @OneToMany(mappedBy = "pharmacie", targetEntity = Garde::class)
//        @JsonIgnore
var gardes: List<Garde>? =null
){



}