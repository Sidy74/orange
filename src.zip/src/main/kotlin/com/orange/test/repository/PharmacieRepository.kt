package com.orange.test.repository

import com.orange.test.dto.PharmacieDto
import com.orange.test.model.Pharmacie
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import java.time.LocalDateTime

interface PharmacieRepository : JpaRepository<Pharmacie, Long> {
    abstract fun save(pharmacieDto: PharmacieDto): PharmacieDto
    abstract fun findByNom(name: String): Pharmacie

//    @Query("SELECT p FROM Pharmacie p JOIN p.gardes g WHERE g.debut <= :now AND g.fin >= :now")
//    fun findPharmaciesWithGardeToday(@Param("now") now: LocalDateTime = LocalDateTime.now()): MutableList<Pharmacie>
}
