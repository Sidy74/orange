package com.orange.test.controller

import GardeServiceImplementation
import com.orange.test.dto.CreateGardeRequestDto
import com.orange.test.dto.GardeDto
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/pharmacies")
class GardeController ( public val gardeServiceImplementation: GardeServiceImplementation
    ) {

    @PostMapping
    fun ajouterGarde(@RequestBody request: CreateGardeRequestDto): ResponseEntity<GardeDto> {
        val garde = gardeServiceImplementation.creerGarde(request)
        return ResponseEntity.status(HttpStatus.CREATED).body(garde)
    }
}