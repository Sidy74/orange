package com.orange.test.dto

data class PharmacieDto(
    var id: Long,
    var nom: String ,
    var adresse: String
) {
}