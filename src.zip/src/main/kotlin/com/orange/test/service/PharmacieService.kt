package com.orange.test.service

import com.orange.test.dto.PharmacieDto
import com.orange.test.model.Pharmacie
import org.springframework.stereotype.Service


interface PharmacieService {

    fun create(pharmacieDto: PharmacieDto): PharmacieDto

    fun readAll(): MutableList<Pharmacie> ;

    fun readById(id: Long): Pharmacie?;

    fun update(id: Long, updatedPharmacie: Pharmacie): Pharmacie?;

    fun delete(id: Long): Boolean ;

    fun deleteByName(name:String):Boolean;
//    abstract fun getPharmaciesWithGardeToday(): MutableList<PharmacieDto>


}