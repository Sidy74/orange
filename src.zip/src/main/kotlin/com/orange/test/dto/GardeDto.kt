package com.orange.test.dto

data class GardeDto(val dateDebut: Any,val dateFin: Any,val id: Long,val pharmacie: PharmacieDto) {
}