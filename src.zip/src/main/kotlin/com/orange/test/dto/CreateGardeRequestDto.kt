package com.orange.test.dto

import java.time.LocalDate

 data class CreateGardeRequestDto (
    val dateDebut: LocalDate,
    val dateFin: LocalDate,
    val pharmacieId: Long
)