import com.orange.test.dto.CreateGardeRequestDto
import com.orange.test.dto.GardeDto
import com.orange.test.dto.PharmacieDto
import com.orange.test.model.Garde
import com.orange.test.repository.GardeRepository
import com.orange.test.repository.PharmacieRepository
import com.orange.test.service.GardeService
import org.springframework.stereotype.Service

@Service
class GardeServiceImplementation(val pharmacieRepository: PharmacieRepository,val gardeRepository: GardeRepository) : GardeService {

    override fun creerGarde(request: CreateGardeRequestDto): GardeDto {
        val pharmacie = pharmacieRepository.findById(request.pharmacieId)
            .orElseThrow { RuntimeException("Pharmacie introuvable") }

        val garde = Garde(
            starDate = request.dateDebut,
            endDate = request.dateFin,
            pharmacie = pharmacie
        )

        val saved = gardeRepository.save(garde)

        return GardeDto(
            id = saved.id,
            dateDebut = saved.starDate,
            dateFin = saved.endDate,
            pharmacie = PharmacieDto(
                id = pharmacie.id,
                nom = pharmacie.nom,
                adresse = pharmacie.adresse,
            )
        )
    }
}