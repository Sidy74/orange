package com.orange.test.service

import com.orange.test.dto.PharmacieDto
import com.orange.test.dto.mapper.PharmacieMapping
import com.orange.test.model.Pharmacie
import com.orange.test.repository.PharmacieRepository
import org.springframework.stereotype.Service
import com.orange.test.dto.mapper.PharmacieMapping.toDto

import com.orange.test.dto.mapper.PharmacieMapping.toEntity

@Service
class PharmacieServiceImplementation ( val pharmacieRepository: PharmacieRepository) : PharmacieService{

    override fun create(pharmacieDto: PharmacieDto): PharmacieDto {
        val saved = pharmacieRepository.save(pharmacieDto.toEntity())
        return saved.toDto()
    }

    override fun readAll(): MutableList<Pharmacie> {
        return pharmacieRepository.findAll().toMutableList()
    }

    override fun readById(id: Long): Pharmacie? {
    return  pharmacieRepository.findById(id).orElseThrow();
    }
    override fun update(id: Long, updatedPharmacie: Pharmacie): Pharmacie? {
        val pharmacie = pharmacieRepository.findById(id).orElse(null)
        return if (pharmacie != null) {
            pharmacie.nom = updatedPharmacie.nom
            pharmacie.adresse = updatedPharmacie.adresse

            pharmacieRepository.save(pharmacie)
        } else {
            null // Retourner null si la pharmacie avec cet id n'existe pas
        }
    }


    override fun delete(id: Long): Boolean {
        return if (pharmacieRepository.existsById(id)) {
            pharmacieRepository.deleteById(id)
            true // Suppression réussie
        } else {
            false // La pharmacie avec cet id n'existe pas
        }
    }


    override fun deleteByName(name: String): Boolean {
        val pharmacie = pharmacieRepository.findByNom(name)
        return if (pharmacie != null) {
            pharmacieRepository.delete(pharmacie)
            true // Suppression réussie
        } else {
            false // Pas de pharmacie avec ce nom
        }
    }

//     override fun getPharmaciesWithGardeToday(): MutableList<PharmacieDto> {
//        val pharmacies = pharmacieRepository.findPharmaciesWithGardeToday()
//        return pharmacies.map { it.toDto() }.toMutableList()
//    }


}