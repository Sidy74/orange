package com.orange.test.dto.mapper

import com.orange.test.dto.PharmacieDto
import com.orange.test.model.Pharmacie

object PharmacieMapping {


    // Extension pour l'entité vers DTO
    fun Pharmacie.toDto(): PharmacieDto {
        return PharmacieDto(
            id = this.id,
            nom = this.nom,
            adresse = this.adresse
        )
    }

    // Extension pour DTO vers entité
    fun PharmacieDto.toEntity(): Pharmacie {
        return Pharmacie(
            id = this.id,
            nom = this.nom,
            adresse = this.adresse
        )
    }
}