package com.orange.test.repository

import com.orange.test.model.Garde
import org.springframework.data.jpa.repository.JpaRepository

interface GardeRepository: JpaRepository<Garde, Long> {
}